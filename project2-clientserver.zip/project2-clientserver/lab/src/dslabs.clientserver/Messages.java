package dslabs.clientserver;

import dslabs.framework.Message;
import lombok.Data;

@Data
class Request implements Message {
    //TODO: message for client request
}

@Data
class Reply implements Message {
    //TODO: message for server reply
}
