package dslabs.testsuites;

import dslabs.kvstore.KVStoreTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(KVStoreTest.class)
public interface Lab2Part1TestSuite {
}
