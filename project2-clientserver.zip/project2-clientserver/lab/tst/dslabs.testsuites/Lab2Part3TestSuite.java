package dslabs.testsuites;

import dslabs.clientserver.ClientServerPart2Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(ClientServerPart2Test.class)
public interface Lab2Part3TestSuite {
}
