package dslabs.testsuites;

import dslabs.clientserver.ClientServerPart1Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(ClientServerPart1Test.class)
public interface Lab2Part2TestSuite {
}
