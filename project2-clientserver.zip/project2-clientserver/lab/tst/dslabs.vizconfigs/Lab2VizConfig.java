package dslabs.vizconfigs;

import dslabs.clientserver.CSVizConfig;

public class Lab2VizConfig extends CSVizConfig {
}
